<div class="col-md-12" >
 <h3>
 Daftar Mata Kuliah
 </h3>
 <table class="table" border="1">
 <thead>
 <tr>
 <th>nama</th><th>sks</th><th>kode</th>
 </thead>
 <tbody>
 <?php
 $nomor=1;
 foreach($list_mtaklah as $mtaklah ){
 ?>
 <tr>
 <td><?=$mtaklah->nama?></td>
 <td><?=$mtaklah->sks?></td>
 <td><?=$mtaklah->kode?></td>
 </tr>
 <?php
 $nomor++;
 }
 ?>
 </tbody>
 </table>
</div>